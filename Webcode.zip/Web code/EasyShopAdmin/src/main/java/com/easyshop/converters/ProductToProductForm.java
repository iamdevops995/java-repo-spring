package com.easyshop.converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.easyshop.commands.ProductForm;
import com.easyshop.domain.Product;

@Component
public class ProductToProductForm implements Converter<Product, ProductForm> {
    @Override
    public ProductForm convert(Product product) {
        ProductForm productForm = new ProductForm();
        productForm.setProductId(product.getProductId());
        productForm.setProductDescription(product.getProductDescription());
        productForm.setProductPrice(product.getProductPrice());
        productForm.setProductImageUrl(product.getProductImageUrl());
        productForm.setProductCount(product.getProductCount());
        return productForm;
    }
}
