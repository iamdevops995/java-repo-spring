package com.easyshop.repositories;

import org.springframework.data.repository.CrudRepository;

import com.easyshop.domain.Product;

public interface ProductRepository extends CrudRepository<Product, Long> {
}
