package com.easyshopwebapp.converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.easyshopwebapp.commands.ProductForm;
import com.easyshopwebapp.domain.Product;

@Component
public class ProductFormToProduct implements Converter<ProductForm, Product> {

    @Override
    public Product convert(ProductForm productForm) {
        Product product = new Product();
        if (productForm.getProductId() != null  && !StringUtils.isEmpty(productForm.getProductId())) {
            product.setProductId(new Long(productForm.getProductId()));
        }
        product.setProductDescription(productForm.getProductDescription());
        product.setProductPrice(productForm.getProductPrice());
        product.setProductImageUrl(productForm.getProductImageUrl());
        product.setProductCount(productForm.getProductCount());
        
        return product;
    }
}
