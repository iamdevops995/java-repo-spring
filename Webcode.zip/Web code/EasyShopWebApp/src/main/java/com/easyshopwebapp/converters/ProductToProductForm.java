package com.easyshopwebapp.converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.easyshopwebapp.commands.ProductForm;
import com.easyshopwebapp.domain.Product;

@Component
public class ProductToProductForm implements Converter<Product, ProductForm> {
    @Override
    public ProductForm convert(Product product) {
        ProductForm productForm = new ProductForm();
        productForm.setProductId(product.getProductId());
        productForm.setProductDescription(product.getProductDescription());
        productForm.setProductPrice(product.getProductPrice());
        productForm.setProductImageUrl(product.getProductImageUrl());
        return productForm;
    }
}
