package com.easyshopwebapp.repositories;

import org.springframework.data.repository.CrudRepository;

import com.easyshopwebapp.domain.Product;

public interface ProductRepository extends CrudRepository<Product, Long> {
}
